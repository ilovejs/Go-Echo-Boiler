CREATE function [dbo].[GetAssessmentClaimID](@TradeItemId bigint)
returns bigint
as    
begin    
	Declare @Id bigint
	select top 1  @Id=Id from  TradeItemClaimHistory 
	where TradeItemId =@TradeItemId
	order by CreatedOn desc
	return @Id
end
go

