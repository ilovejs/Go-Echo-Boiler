CREATE PROC [dbo].[GetTradeSummary](@ProjectId bigint)
AS
/*
exec GetTradeSummary 202
*/
BEGIN
	SELECT TI.TradeId,TM.TradeName ,ISNULL(SUM(TI.ItemBreakdown),0) AS ItemBreakdown
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
	WHERE  TI.ProjectId = @ProjectId AND TI.IsDeleted = 0 AND TI.TempCheck = 0 AND TM.IsDeleted = 0
	GROUP BY TI.TradeId,TM.TradeName
	ORDER BY TI.TradeId 
END



go

