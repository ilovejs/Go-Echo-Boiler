CREATE   PROC [dbo].[GetClaimhistory](@TradeclaimId bigint)
AS
/*
exec GetClaimhistory 10168
*/
BEGIN
	SELECT CM.Id,CM.TradeItemId,CM.TradeItemClaimId,CM.PreviousClaimed,CM.CreatedOn,CM.CreatedBy,UR.UserRoleType,
		Convert(varchar,CM.CreatedOn,103) As Date
    FROM TradeItemClaimHistory AS CM
		JOIN UserProfile AS UP ON UP.Id = CM.CreatedBy
		JOIN UserLogin AS UL ON UL.Id = UP.UserLoginId
		JOIN UserRole AS UR ON UR.Id = UL.UserRoleId
		--JOIN TradeItemClaim AS TC ON TC.Id = CM.TradeItemClaimId
	WHERE  CM.TradeItemId = @TradeclaimId --AND TC.ActionClaim = 1
	ORDER BY CM.Id DESC
END



go

