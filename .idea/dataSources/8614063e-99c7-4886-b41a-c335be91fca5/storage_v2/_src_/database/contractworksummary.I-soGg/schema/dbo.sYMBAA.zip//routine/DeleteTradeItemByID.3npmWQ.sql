
CREATE  PROC [dbo].[DeleteTradeItemByID](@Id bigint)
AS
BEGIN
	DELETE FROM TradeItem
    WHERE  Id = @Id 
END



go

