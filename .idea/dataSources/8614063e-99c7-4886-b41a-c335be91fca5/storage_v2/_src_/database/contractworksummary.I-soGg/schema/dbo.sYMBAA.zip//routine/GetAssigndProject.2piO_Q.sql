CREATE   PROC [dbo].[GetAssigndProject](@UserProfileId bigint)
AS
/*
exec GetAssigndProject 10014
*/
BEGIN
    SELECT P.Id,P.UserId,P.CreatedBy,P.Name,P.TotalItemBreakdown,P.ContractorTotalClaim,P.ProjectNumber,
		P.ProjectDetails,P.QuantitySurveyor,p.TotalContractAmount,P.SiteNote,
		(UP.FirstName +' '+UP.LastName +'('+ UP.Email + ')') AS Contractor
	FROM Project AS P
		JOIN UserProfile AS UP ON UP.UserLoginId = P.UserId
	WHERE P.UserId= @UserProfileId AND P.IsDeleted = 0 AND [dbo].[GetActiveTradeItemCount](P.Id) > 0
END

go

