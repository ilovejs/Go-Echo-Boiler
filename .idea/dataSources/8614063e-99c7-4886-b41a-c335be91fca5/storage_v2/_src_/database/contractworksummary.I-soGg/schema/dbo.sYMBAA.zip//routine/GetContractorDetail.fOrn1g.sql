CREATE PROC [dbo].[GetContractorDetail](@LoginUserID BIGINT) 
/*
exec GetContractorDetail 2
*/
AS
BEGIN
	SELECT L.ID AS UserLoginID,P.Id AS UserProfileID,L.UserName, P.FirstName,P.LastName,P.Email,P.MobileNo,
		L.IsActive,L.IsDeleted,P.Company
	FROM UserLogin AS L
		JOIN UserProfile AS P ON P.UserLoginId = L.Id
	WHERE  L.ID = @LoginUserID
END
go

