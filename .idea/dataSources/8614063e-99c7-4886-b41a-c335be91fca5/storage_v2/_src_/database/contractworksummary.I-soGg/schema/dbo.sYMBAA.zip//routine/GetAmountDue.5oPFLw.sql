CREATE function [dbo].[GetAmountDue](@TradeItemId int)
returns decimal(18,2)
as    
begin    
	Declare @AmountDue Decimal(18,2)
	select top 1  @AmountDue= SUM(TC.AmountDue) from TradeItem as TT 
		join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeItemId
	return @AmountDue
end
go

