CREATE  PROC [dbo].[ProjectTradeDetailClaim](@ProjectId bigint)
AS
/*
exec ProjectTradeDetailClaim 10162
*/
BEGIN
	SELECT TI.Id,TI.TradeId,TM.TradeName,TI.ProjectId,SUM(TI.ItemBreakDown) AS Total,
	TM.TradeName,isnull([dbo].[GetPreviousClaim](TI.Id,@ProjectId),0)PreviousClaim 
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
	WHERE TI.ProjectId = @ProjectId AND TI.TempCheck = 0 AND TM.IsDeleted = 0 group by TI.TradeId ,TI.ProjectId,TM.TradeName,TI.Id
END



go

