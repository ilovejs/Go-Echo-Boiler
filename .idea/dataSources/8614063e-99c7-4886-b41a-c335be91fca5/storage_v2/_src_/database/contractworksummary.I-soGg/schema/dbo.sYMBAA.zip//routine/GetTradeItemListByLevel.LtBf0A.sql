
CREATE PROC [dbo].[GetTradeItemListByLevel](@ProjectId bigint,@level VARCHAR(200))
--exec GetTradeItemListByLevel 
AS
BEGIN
	SELECT TI.Id,TI.TradeId,TI.[Level],TI.DescriptionOfWork,TI.ProjectId,TI.ItemBreakdown,
		TM.TradeName,ISNULL([dbo].[GetPreviousClaimById](TI.ID),0)PreviousClaim,
		ISNULL([dbo].[GetClaimAmount](TI.ID),0)ClaimAmount,
		ISNULL([dbo].[GetClaimHistoryID](TI.ID),0)ClaimHistoryId
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
		JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 and TI.Level= @level 
END



go

