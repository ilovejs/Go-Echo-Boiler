
CREATE function [dbo].[GetActionClaim](@TradeItemId bigint)
returns bit
as    
begin    
	Declare @Status bit
	select top 1   @Status=ActionClaim from  TradeItemClaim 
	where TradeItemId =@TradeItemId
	return @Status
end
go

