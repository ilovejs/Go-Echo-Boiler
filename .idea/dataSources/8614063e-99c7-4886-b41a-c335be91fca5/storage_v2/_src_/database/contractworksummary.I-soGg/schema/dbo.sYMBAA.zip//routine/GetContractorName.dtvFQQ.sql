CREATE function [dbo].[GetContractorName](@ProjectId bigint)
returns VARCHAR(MAX)
as    
begin    
	Declare @Name VARCHAR(MAX)
	select  @Name= (U.FirstName+' '+U.LastName)  from UserProfile as U 
		join Project as P on P.UserId = U.Id 
	where P.Id = @ProjectId
	return @Name
end
go

