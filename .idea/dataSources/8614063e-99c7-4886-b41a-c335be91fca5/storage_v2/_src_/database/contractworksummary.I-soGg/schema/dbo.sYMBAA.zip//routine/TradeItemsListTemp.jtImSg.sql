CREATE  PROC [dbo].[TradeItemsListTemp](@ProjectId bigint,@TradeId int)
AS
/*
exec TradeItemsListTemp 11,44

*/
BEGIN
	SELECT TI.Id,TI.TradeId,TI.ProjectId,TI.[Level],TI.DescriptionOfWork,TI.ItemBreakdown,TM.TradeName
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
	WHERE  TI.ProjectId = @ProjectId AND TI.TradeId = @TradeId 
END



go

