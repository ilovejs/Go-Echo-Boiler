
CREATE function [dbo].[GetClaimAmount](@TradeItemId bigint)
returns decimal(18,2)
as    
begin    
	Declare @PClaimAmount Decimal(18,2)
	select  @PClaimAmount= ClaimedAmount  from  TradeItemClaim
	where TradeItemId =@TradeItemId and ActionClaim = 0 and AutoIncrement = (select MAX(AutoIncrement) from TradeItemClaim where TradeItemId =@TradeItemId)
	return @PClaimAmount
end
go

