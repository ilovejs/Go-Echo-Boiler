
CREATE PROC [dbo].[GetApprovedClaimNumberList](@ProjectId bigint)
--exec GetApprovedClaimNumberList 20271
AS
BEGIN
	SELECT TC.AutoIncrement AS Id,TC.ClaimPeriod,TC.[ClaimNumber]
	FROM TradeItemClaim AS TC
	    JOIN TradeItem AS TI ON TC.TradeItemId = TI.Id
	WHERE  TI.ProjectId = @ProjectId AND TC.ActionClaim = 1
	group by TC.AutoIncrement,TC.ClaimPeriod,TC.[ClaimNumber]
	order by TC.AutoIncrement desc
END
go

