CREATE function [dbo].[GetProjectCount](@UserProfileId bigint)
returns int
as    
begin    
	Declare @ProjectCnt int
	select @ProjectCnt=count(Q.Id) from Project as  Q 
	where Q.UserId=@UserProfileId and isnull(Q.isdeleted,0)=0 and [dbo].[GetActiveTradeItemCount](Q.Id) > 0
	return @ProjectCnt
end
go

