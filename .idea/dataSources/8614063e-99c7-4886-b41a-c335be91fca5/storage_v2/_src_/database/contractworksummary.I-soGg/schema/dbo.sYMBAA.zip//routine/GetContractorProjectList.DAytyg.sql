CREATE   PROC [dbo].[GetContractorProjectList](@UserId bigint)
AS
BEGIN
	SELECT P.Id,P.UserId,P.CreatedBy,P.Name,P.TotalItemBreakdown,P.ContractorTotalClaim,P.ProjectNumber,p.ProjectDetails,P.QuantitySurveyor,p.TotalContractAmount,P.SiteNote,
		[dbo].[GetActiveTradeItemCount](P.Id) AS TotalTradeItem,
		(UP.FirstName +' '+UP.LastName +'('+ UP.Email + ')') AS Contractor
	FROM Project AS P
	   LEFT JOIN (SELECT COUNT(Id) AS  TotalTradeItem,ProjectId FROM TradeItem WHERE IsDeleted=0 AND TempCheck=0 GROUP BY ProjectId  ) AS AC ON  P.Id = AC.ProjectId
	   JOIN UserProfile AS UP ON UP.UserLoginId = P.UserId
	WHERE isnull(P.IsDeleted,0)=0 and p.UserId=@UserId AND [dbo].[GetActiveTradeItemCount](P.Id) > 0
	ORDER BY  P.Id DESC 
END

go

