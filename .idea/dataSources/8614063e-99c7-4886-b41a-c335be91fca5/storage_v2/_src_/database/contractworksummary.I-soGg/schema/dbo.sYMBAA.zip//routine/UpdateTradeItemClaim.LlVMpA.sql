
CREATE PROC [dbo].[UpdateTradeItemClaim](@TradeItemId bigint,@Month varchar(50),@Number varchar(200))
AS
BEGIN
   UPDATE TradeItemClaim
   SET ActionClaim = 0,ClaimNumber = @Number,ClaimPeriod = @Month
   WHERE TradeItemId = @TradeItemId AND AutoIncrement = [dbo].[GetMaxAutoIncrement](@TradeItemId)   
END



go

