
CREATE function [dbo].[GetClaimedAssessmentReport](@TradeId bigint,@ProjectId bigint,@Month varchar(50),@ClaimNumber varchar(200))
returns decimal(18,2)
as    
begin    
Declare @CAmount Decimal(18,2)
	select @CAmount= SUM(TC.ClaimedAmount) from TradeItem as TT 
		join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeId  and TT.ProjectId = @ProjectId and TC.ActionClaim = 1 and TC.ClaimPeriod = @Month and TC.ClaimNumber = @ClaimNumber 
	group by TT.TradeId
	return @CAmount
end
go

