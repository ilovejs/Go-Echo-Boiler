CREATE PROC [dbo].[GetTradeItemLevelList](@ProjectId bigint)
AS
/*
exec GetTradeItemLevelList 20272
*/
BEGIN
	SELECT DISTINCT TI.ProjectId AS Id, TI.[Level]  AS Level
	FROM TradeItem AS TI
	WHERE  TI.ProjectId = @ProjectId 
	ORDER BY TI.[Level]
END



go

