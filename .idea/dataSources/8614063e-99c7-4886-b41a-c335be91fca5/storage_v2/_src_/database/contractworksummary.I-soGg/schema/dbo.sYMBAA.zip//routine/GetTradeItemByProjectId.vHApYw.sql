
CREATE PROC [dbo].[GetTradeItemByProjectId](@ProjectId bigint)
AS
/*
exec GetTradeList 10200
*/
BEGIN
	SELECT TI.Id
	FROM TradeItem AS TI
	WHERE  TI.ProjectId = @ProjectId  AND TI.IsDeleted = 0 AND TI.TempCheck = 0 
	ORDER BY TI.Id 
END



go

