
create function [dbo].[GetMaxAutoIncrement](@TradeItemId int)
returns bigint
as    
begin    
	Declare @Maxvalue bigint
	select @Maxvalue =MAX(AutoIncrement) FROM TradeItemClaim 
	where TradeItemId =@TradeItemId
	return @Maxvalue
end
go

