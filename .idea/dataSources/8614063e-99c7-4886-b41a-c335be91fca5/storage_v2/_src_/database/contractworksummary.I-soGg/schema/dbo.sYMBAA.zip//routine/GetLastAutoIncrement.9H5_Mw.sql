CREATE   PROC [dbo].[GetLastAutoIncrement](@ProjectId bigint)
AS
/*
*/
BEGIN
	SELECT CASE WHEN TC.ActionClaim IS NULL THEN ISNULL(Max(TC.AutoIncrement),0) ELSE ISNULL(Max(TC.AutoIncrement),0)+1 END FROM TradeItemClaim AS TC
		JOIN TradeItem AS TI ON TI.Id = TC.TradeItemId 
	WHERE TI.ProjectId = @ProjectId 
	GROUP BY TC.ActionClaim
END

go

