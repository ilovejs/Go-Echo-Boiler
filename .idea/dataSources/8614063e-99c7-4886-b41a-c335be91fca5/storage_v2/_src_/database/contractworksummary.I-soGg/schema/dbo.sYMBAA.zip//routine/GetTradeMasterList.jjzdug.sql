CREATE PROC [dbo].[GetTradeMasterList] 
/*
exec GetTradeMasterList
*/
AS
BEGIN
	SELECT Id , TradeName FROM TradeMaster
	WHERE IsDeleted = 0 
END
go

