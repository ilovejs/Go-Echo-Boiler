
CREATE function [dbo].[GetClaimedAmountAssessment](@TradeId bigint,@Id bigint)
returns decimal(18,2)
as    
begin    
	Declare @CAmount Decimal(18,2)
	select  @CAmount= SUM(TC.ClaimedAmount) from TradeItem as TT join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeId and TC.AutoIncrement = @Id
	group by TT.TradeId
	return @CAmount
end
go

