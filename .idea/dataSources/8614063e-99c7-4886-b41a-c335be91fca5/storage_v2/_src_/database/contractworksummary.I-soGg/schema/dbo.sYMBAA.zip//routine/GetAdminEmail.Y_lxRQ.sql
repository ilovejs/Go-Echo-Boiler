CREATE   PROC [dbo].[GetAdminEmail](@ProjectId bigint)
AS
--exec GetAdminEmail 10165
BEGIN
	SELECT Email,isnull([dbo].[GetContractorName](@ProjectId),'')Name 
	FROM UserProfile AS P
		JOIN UserLogin AS L ON P.UserLoginId = L.id
		JOIN UserRole AS R ON R.Id = L.UserRoleId
	WHERE R.UserRoleType = 'On-site Team'
END



go

