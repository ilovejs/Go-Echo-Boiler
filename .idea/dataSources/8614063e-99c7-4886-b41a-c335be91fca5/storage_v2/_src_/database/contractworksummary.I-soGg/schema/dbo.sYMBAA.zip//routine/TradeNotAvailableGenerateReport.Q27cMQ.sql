
CREATE PROC [dbo].[TradeNotAvailableGenerateReport](@ProjectId bigint)
--exec TradeGenerateReport 20262
AS
BEGIN
	SELECT TM.Id,TM.TradeName,0 AS ItemBreakdownAmount,
	      0 AS ClaimedAmount,
		  0 AS PreviousClaim
		  FROM TradeMaster AS TM
			
	WHERE   TM.Id IN (33,34,35,36,37) 

	ORDER BY TM.Id
END



go

