
create function [dbo].[GetApprovedClaimProjectCount](@ProjectId bigint)
returns int
as    
begin    
	Declare @ClaimCnt int
	select @ClaimCnt= COUNT(TC.Id) from TradeItem as TT 
		join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.ProjectId=@ProjectId and TC.ActionClaim = 1
	return @ClaimCnt
end


go

