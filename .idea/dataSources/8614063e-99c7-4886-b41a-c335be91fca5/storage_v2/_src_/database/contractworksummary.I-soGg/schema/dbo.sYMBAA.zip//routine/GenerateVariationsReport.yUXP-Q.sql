

CREATE PROC [dbo].[GenerateVariationsReport](@ProjectId bigint,@Month varchar(50),@ClaimNumber varchar(200))
--exec GenerateVariationsReport 20272,'January','1'

AS

BEGIN
   	SELECT TI.TradeId AS TradeId,TM.TradeName AS TradeName,TI.[Level],TI.DescriptionOfWork,TI.ItemBreakdown AS ItemBreakdown,P.Name,
	     ISNULL([dbo].[GetClaimedAssessmentReport](TI.TradeId,@ProjectId,@Month,@ClaimNumber),0)ClaimAmount,
		 ISNULL([dbo].[GetReportPreviousClaim](TI.TradeId,@ProjectId,(TC.AutoIncrement-1)),0)PreviousClaim,
		  @ClaimNumber AS ClaimNumber,
		  CAST( CAST(year(getdate())  AS varchar) + '-' + CAST(@Month AS varchar) + '-' + CAST(1 AS varchar) as datetime) AS StartDate,
		  DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,CAST( CAST(year(getdate())  AS varchar) + '-' + CAST(@Month AS varchar) + '-' + CAST(1 AS varchar) as datetime))+1,0)) AS EndDate
          FROM TradeItem AS TI
			JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
			JOIN TradeItemClaim AS TC ON TC.TradeItemId = TI.Id
			JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId  AND TC.ClaimPeriod = @Month AND TC.ClaimNumber =  @ClaimNumber AND TI.TempCheck = 0 AND TI.TradeId IN (33,34,35,36,37) 
	GROUP BY TI.TradeId,TM.TradeName,TI.ProjectId,P.Name,TC.ClaimNumber,TC.ClaimPeriod,TI.[Level],TI.DescriptionOfWork,TI.ItemBreakdown,TC.AutoIncrement
	ORDER BY TI.TradeId
END



go

