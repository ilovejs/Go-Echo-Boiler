CREATE function [dbo].[GetClaimedAmount](@TradeItemId int)
returns decimal(18,2)
as    
begin    
	Declare @CAmount Decimal(18,2)
	select top 1  @CAmount= SUM(TC.ClaimedAmount) from TradeItem as TT join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeItemId and TC.AutoIncrement = [dbo].[GetMaxAutoIncrement](TC.TradeItemId) and TC.ActionClaim is null
	return @CAmount
end
go

