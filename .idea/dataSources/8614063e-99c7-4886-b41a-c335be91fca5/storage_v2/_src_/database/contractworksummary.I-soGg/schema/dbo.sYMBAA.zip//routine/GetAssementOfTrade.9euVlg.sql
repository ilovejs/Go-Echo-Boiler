
CREATE PROC [dbo].[GetAssementOfTrade](@ProjectId bigint,@TradeId int,@AutoId bigint)
--exec GetAssementOfTrade 20272,1,4
AS
BEGIN
	SELECT TI.Id,TI.[Level],TI.DescriptionOfWork,TI.ProjectId,TI.ItemBreakdown,
		ISNULL([dbo].[GetPreviousApprovedClaimById](TI.ID,@AutoId-1),0)PreviousClaim,
		TC.ActionClaim AS ActionClaim,TC.Id AS TradeItemClaimId,
		isnull([dbo].[GetClaimHistoryID](TI.ID),0)ClaimHistoryId,
		TC.ClaimPercentage,
		TC.ClaimedAmount AS ApproveClaimed , TM.Id AS TradeID , TM.TradeName AS TradeName
	FROM TradeItem AS TI
	    JOIN TradeItemClaim AS TC ON TI.ID = TC.TradeItemId
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
		JOIN Project AS P On P.id = @ProjectId
	WHERE TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 AND TI.TradeId = @TradeId  AND TC.AutoIncrement = @AutoId
END



go

