CREATE PROC [dbo].[ContractorActiveList] 
/*
exec ContractorList
*/
AS
BEGIN
	SELECT L.ID AS UserLoginID,P.Id AS UserProfileID,L.UserName, P.FirstName,P.LastName,P.Email,P.MobileNo , L.IsActive,L.IsDeleted,P.Company
	FROM UserLogin AS L
		JOIN UserProfile AS P ON P.UserLoginId = L.Id
	WHERE L.CreatedBy IS NOT NULL AND L.IsDeleted = 0 AND  L.IsActive = 1
	ORDER BY L.Id DESC
END
go

