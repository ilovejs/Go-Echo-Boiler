
create function [dbo].[GetTotalAmount](@ProjectId bigint)
returns decimal(18,2)
as    
begin    
	Declare @TotalAmount Decimal(18,2)
	select @TotalAmount= SUM(ItemBreakDown) from TradeItem 
	where ProjectId =@ProjectId AND TempCheck = 0 group by ProjectId
	return @TotalAmount 
end
go

