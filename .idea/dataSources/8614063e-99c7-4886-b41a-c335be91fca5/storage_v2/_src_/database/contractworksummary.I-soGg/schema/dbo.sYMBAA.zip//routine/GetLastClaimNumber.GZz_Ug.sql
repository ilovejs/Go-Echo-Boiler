
CREATE function [dbo].[GetLastClaimNumber](@TradeId bigint,@ProjectId bigint)
returns varchar(max)
as    
begin    
Declare @ClaimNumber varchar(max)
	select top 1 @ClaimNumber= TC.ClaimNumber from TradeItem as TT 
		join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeId and TT.ProjectId = @ProjectId and TC.ActionClaim = 1 
	order by TC.AutoIncrement desc
	return @ClaimNumber
end
go

