
CREATE PROC [dbo].[GetTradeOfProjectReport](@ProjectId bigint)
--exec GetTradeOfProjectReport 20269
AS
BEGIN
	SELECT distinct TI.TradeId,TM.TradeName
	FROM TradeItem AS TI
	  	JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
	WHERE  TI.ProjectId = @ProjectId 
END



go

