
CREATE function [dbo].[GetReportPreviousClaim](@TradeId int,@ProjectId bigint, @AutoIncrement bigint)
returns decimal(18,2)
as    
begin 
     Declare @PClaimAmount Decimal(18,2)
	select top 1  @PClaimAmount= SUM(TH.PreviousClaimed) from  TradeItemClaimHistory AS TH
		join TradeItemClaim AS TC ON TC.Id = TH.TradeItemClaimId
		join TradeItem AS TI ON TI.Id = TC.TradeItemId
	where TI.ProjectId=@ProjectId AND TC.ActionClaim = 1 AND TI.TradeId =@TradeId and TH.AutoIncrement =@AutoIncrement
	group by TH.AutoIncrement
	order by TH.AutoIncrement desc
	
	return @PClaimAmount
end
go

