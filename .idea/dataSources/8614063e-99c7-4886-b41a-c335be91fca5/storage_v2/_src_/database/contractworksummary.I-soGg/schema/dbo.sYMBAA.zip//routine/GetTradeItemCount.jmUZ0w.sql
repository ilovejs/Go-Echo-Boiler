CREATE function [dbo].[GetTradeItemCount](@ProjectId bigint)
returns int
as    
begin    
	Declare @ItemCnt int
	select @ItemCnt=count(Id) from TradeItem as  Q 
	where Q.ProjectId=@ProjectId and isnull(isdeleted,0)=0
	return @ItemCnt
end
go

