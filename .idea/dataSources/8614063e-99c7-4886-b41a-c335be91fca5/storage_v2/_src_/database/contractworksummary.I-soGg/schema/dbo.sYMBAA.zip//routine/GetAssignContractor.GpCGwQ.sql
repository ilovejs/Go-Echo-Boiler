CREATE   PROC [dbo].[GetAssignContractor](@ProjectId bigint)
AS
/*
exec GetAssignContractor 11
*/
BEGIN
    SELECT AC.Id AS AssignContarctorID,AC.UserId,AC.ProjectId,AC.TradeId,AC.SiteNotes,
		[dbo].[GetTradeItemCount](AC.ProjectId) AS ItemCount,TM.TradeName,
		(UP.FirstName +' '+UP.LastName +'('+ UP.Email + ')') AS Contractor
    FROM AssignContarctor AS AC
		JOIN UserProfile AS UP ON UP.UserLoginId = AC.UserId
		JOIN TradeMaster AS TM ON TM.Id = AC.TradeId
    WHERE  AC.ProjectId = @ProjectId
END

go

