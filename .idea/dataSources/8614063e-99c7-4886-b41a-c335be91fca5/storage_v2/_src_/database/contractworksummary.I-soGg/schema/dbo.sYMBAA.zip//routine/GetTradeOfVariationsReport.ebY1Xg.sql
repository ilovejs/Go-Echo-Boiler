

CREATE PROC [dbo].[GetTradeOfVariationsReport](@ProjectId bigint)
--exec GetTradeOfVariationsReport 20272
AS
BEGIN
	SELECT distinct TI.TradeId,TM.TradeName
	FROM TradeItem AS TI
	  	JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
	WHERE  TI.ProjectId = @ProjectId AND TM.Id IN (33,34,35,36,37)
END



go

