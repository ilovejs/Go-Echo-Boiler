
CREATE   PROC [dbo].[GetApprovedClaimProjectList]
AS
/*
Admin
exec GetAllProjectList
*/
BEGIN
	SELECT P.Id,P.Name FROM Project AS P
	WHERE P.IsDeleted=0 AND [dbo].[GetActiveTradeItemCount](P.Id) > 0 AND [dbo].[GetApprovedClaimProjectCount](P.Id) > 0 
	ORDER BY  P.Id DESC 
END

go

