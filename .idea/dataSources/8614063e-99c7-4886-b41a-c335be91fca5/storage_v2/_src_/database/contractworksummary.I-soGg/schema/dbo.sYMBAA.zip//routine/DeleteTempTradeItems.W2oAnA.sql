CREATE  PROC [dbo].[DeleteTempTradeItems](@ProjectId bigint,@TradeId int)
AS
/*
Admin
exec DeleteTempTradeItems 10069,3
*/
BEGIN
	DELETE FROM TradeItem
    WHERE  ProjectId = @ProjectId AND TradeId = @TradeId  AND TempCheck = 1
END



go

