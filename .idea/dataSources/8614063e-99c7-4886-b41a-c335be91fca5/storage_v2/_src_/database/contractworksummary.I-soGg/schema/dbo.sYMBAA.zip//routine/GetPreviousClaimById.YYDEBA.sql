CREATE function [dbo].[GetPreviousClaimById](@TradeItemId bigint)
returns decimal(18,2)
as    
begin    
	Declare @PClaimAmount Decimal(18,2)
	select top 1  @PClaimAmount= SUM(TH.PreviousClaimed) from  TradeItemClaimHistory AS TH
		join TradeItemClaim AS TC ON TC.Id = TH.TradeItemClaimId
	where TH.TradeItemId =@TradeItemId AND TC.ActionClaim = 1 
	group by TH.AutoIncrement
	order by TH.AutoIncrement desc
	return @PClaimAmount
end
go

