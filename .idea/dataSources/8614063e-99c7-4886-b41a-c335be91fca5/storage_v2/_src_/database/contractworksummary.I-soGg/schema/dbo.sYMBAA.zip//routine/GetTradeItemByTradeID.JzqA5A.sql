
CREATE PROC [dbo].[GetTradeItemByTradeID](@ProjectId bigint,@TradeId int)

AS
BEGIN
	SELECT TI.Id,TI.TradeId,TI.[Level],TI.DescriptionOfWork,TI.ProjectId,TI.ItemBreakdown,
		TM.TradeName,ISNULL([dbo].[GetPreviousClaimById](TI.ID),0)PreviousClaim,
		ISNULL([dbo].[GetClaimedAmountById](TI.ID),0)ClaimedAmount
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
		JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 and Ti.TradeId= @TradeId 
END



go

