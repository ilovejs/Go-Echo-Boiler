CREATE   PROC [dbo].[GetTradeUseCount](@TradeId int)
AS
/*
select * from GetTradeUseCount
*/
BEGIN
	SELECT COUNT(TI.Id) AS TradeCount
	FROM TradeItem AS TI
	WHERE TI.TradeId = @TradeId AND TI.IsDeleted = 0
END



go

