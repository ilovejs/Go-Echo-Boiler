CREATE   PROC [dbo].[GetTradeItemByID](@Id bigint)
AS
/*
exec GetTradeList 10157
*/
BEGIN
	SELECT TI.Id,TI.TradeId,TI.ProjectId,TI.[Level],TI.DescriptionOfWork,TI.ItemBreakdown,TM.TradeName
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
	WHERE  TI.Id = @Id AND TI.IsDeleted = 0 AND TI.TempCheck = 0
END



go

