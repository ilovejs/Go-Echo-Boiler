
CREATE PROC [dbo].[GenerateProjectClaimReport](@ProjectId bigint)
--exec GenerateProjectClaimReport 20269
AS
BEGIN
	SELECT TC.[AutoIncrement],TC.[ClaimNumber],P.Name,TI.Id,TI.TradeId,TI.[Level],TI.DescriptionOfWork,TI.ProjectId,TI.ItemBreakdown,
		TM.TradeName,ISNULL([dbo].[GetPreviousClaimById](TI.ID),0)PreviousClaim,

		ISNULL([dbo].[GetReportClaimAmount](TI.ID),0)ClaimAmount,
		CAST( CAST(year(getdate())  AS varchar) + '-' + CAST(TC.ClaimPeriod AS varchar) + '-' + CAST(1 AS varchar) as datetime) AS StartDate,
		DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,CAST( CAST(year(getdate())  AS varchar) + '-' + CAST(TC.ClaimPeriod AS varchar) + '-' + CAST(1 AS varchar) as datetime))+1,0)) AS EndDate
	FROM TradeItem AS TI
	    JOIN TradeItemClaim AS TC ON TC.TradeItemId = TI.Id
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
		JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId and TC.[AutoIncrement] = (select MAX(AutoIncrement) FROM TradeItemClaim where TradeItemId =TI.Id)
	
END



go

