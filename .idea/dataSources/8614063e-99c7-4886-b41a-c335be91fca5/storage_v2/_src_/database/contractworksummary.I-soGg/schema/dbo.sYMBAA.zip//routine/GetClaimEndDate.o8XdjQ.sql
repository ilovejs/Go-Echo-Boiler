
CREATE function [dbo].[GetClaimEndDate](@TradeId bigint,@ProjectId bigint)
returns datetime
as    
begin    
Declare @month varchar(50)
	select top 1 @month= TC.ClaimPeriod from TradeItem as TT 
		join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeId and TT.ProjectId = @ProjectId and TC.ActionClaim = 1 
	order by TC.AutoIncrement desc
	return DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,CAST( CAST(year(getdate())  AS varchar) + '-' + CAST(@month AS varchar) + '-' + CAST(1 AS varchar) as datetime))+1,0))
end
go

