CREATE PROC [dbo].[GetClaimSummaryByMonth](@ProjectId bigint)
--exec GetClaimSummaryByMonth 101624
AS
BEGIN
	SELECT SUM(TC.ClaimedAmount) AS Amount,TC.ActionClaim,
	     TC.ClaimPeriod AS CreatedMonthName,TC.AutoIncrement
    FROM TradeItemClaim AS TC
			JOIN TradeItem AS TI ON TI.id = TC.TradeItemId 
	WHERE  TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 AND (TC.ActionClaim = 0 OR TC.ActionClaim = 1)
	GROUP BY TC.ClaimPeriod,TC.ActionClaim,TC.AutoIncrement
	ORDER BY TC.AutoIncrement DESC
END



go

