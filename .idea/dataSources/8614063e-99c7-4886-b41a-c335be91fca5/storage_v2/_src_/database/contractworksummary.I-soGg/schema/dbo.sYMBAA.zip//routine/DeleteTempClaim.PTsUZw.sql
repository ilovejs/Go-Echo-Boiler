

CREATE  PROC [dbo].[DeleteTempClaim]
AS
BEGIN
	DELETE FROM TradeItemClaimHistory
    WHERE TradeItemClaimId IN (SELECT Id FROM TradeItemClaim
    WHERE ActionClaim IS NULL)

	DELETE FROM TradeItemClaim
    WHERE ActionClaim IS NULL 
END



go

