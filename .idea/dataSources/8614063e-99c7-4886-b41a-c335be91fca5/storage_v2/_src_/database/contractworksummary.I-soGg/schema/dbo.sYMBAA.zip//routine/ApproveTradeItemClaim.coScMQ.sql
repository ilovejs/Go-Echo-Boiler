CREATE PROC [dbo].[ApproveTradeItemClaim](@AutoId bigint)
AS
BEGIN
   UPDATE TradeItemClaim
   SET ActionClaim = 1
   WHERE AutoIncrement =  @AutoId
END



go

