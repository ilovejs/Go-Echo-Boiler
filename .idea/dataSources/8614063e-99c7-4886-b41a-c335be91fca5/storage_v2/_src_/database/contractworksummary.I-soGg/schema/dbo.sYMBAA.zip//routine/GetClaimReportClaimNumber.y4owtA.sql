
CREATE function [dbo].[GetClaimReportClaimNumber](@TradeItemId bigint,@ProjectId bigint)
returns varchar(max)
as    
begin    
Declare @ClaimNumber varchar(max)
	select top 1 @ClaimNumber= ClaimNumber from TradeItemClaim 
	where TradeItemId =@TradeItemId and ActionClaim = 0
	order by AutoIncrement desc
	return @ClaimNumber
end
go

