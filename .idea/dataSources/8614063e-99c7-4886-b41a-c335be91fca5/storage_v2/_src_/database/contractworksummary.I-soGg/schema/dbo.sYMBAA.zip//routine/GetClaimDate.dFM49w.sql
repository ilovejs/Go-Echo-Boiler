
CREATE function [dbo].[GetClaimDate](@TradeId bigint,@ProjectId bigint)
returns datetime
as    
begin    
Declare @date datetime
	select top 1 @date= TC.UpdatedOn from TradeItem as TT 
		join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeId and TT.ProjectId = @ProjectId
	order by TC.AutoIncrement



	 
	return DATEADD(mm, DATEDIFF(mm, 0, @date), 0)
end
go

