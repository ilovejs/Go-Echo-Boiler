
CREATE function [dbo].[GetAssessmentPreviousClaim](@TradeItemId bigint)
returns decimal(18,2)
as    
begin    
	Declare @PClaimAmount Decimal(18,2)
	select top 2  @PClaimAmount= PreviousClaimed from  TradeItemClaimHistory 
	where TradeItemId =@TradeItemId
	order by CreatedOn desc
	return @PClaimAmount
end
go

