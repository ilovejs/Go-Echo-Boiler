
CREATE PROC [dbo].[TradeItemsDetail](@ProjectId bigint)
--exec TradeItemsDetail 20215
AS
BEGIN
	SELECT TradeId,SUM(TI.ItemBreakdown) AS TotalAmount,TM.TradeName,
		ISNULL([dbo].[GetPreviousClaim](TI.TradeId,@ProjectId),0)PreviousClaim,
		ISNULL([dbo].[GetCostToCompleted](TI.TradeId),0)CostToCompleted,
		ISNULL([dbo].[GetAmountDue](TI.TradeId),0)AmountDue,
		ISNULL([dbo].[GetClaimedAmount](TI.TradeId),0)ClaimedAmount
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
		JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 GROUP BY TI.TradeId,TM.TradeName,TI.ProjectId
END



go

