CREATE   PROC [dbo].[GetProjectDetailById](@ProjectId bigint)
AS
/*
exec GetAllProjectList
*/
BEGIN
	SELECT P.Id,P.UserId,P.CreatedBy,P.Name,P.TotalItemBreakdown,P.ContractorTotalClaim,P.ProjectNumber,p.ProjectDetails,P.QuantitySurveyor,p.TotalContractAmount,P.SiteNote,
		(UP.FirstName +' '+UP.LastName +'('+ UP.Email + ')') AS Contractor
	FROM Project AS P
		JOIN UserProfile AS UP ON UP.UserLoginId = P.UserId
	WHERE P.Id= @ProjectId
END

go

