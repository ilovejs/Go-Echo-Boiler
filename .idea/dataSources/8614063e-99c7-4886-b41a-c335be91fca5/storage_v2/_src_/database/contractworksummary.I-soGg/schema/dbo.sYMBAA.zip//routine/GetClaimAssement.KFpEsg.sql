
CREATE PROC [dbo].[GetClaimAssement](@ProjectId bigint,@AutoId bigint)
--exec GetClaimAssement 20220,1
AS
BEGIN
	SELECT TI.TradeId,SUM(TI.ItemBreakdown) AS TotalAmount,
	      TM.TradeName,ISNULL([dbo].[GetPreviousApprovedClaim](TI.TradeId,@ProjectId,(@AutoId-1)),0)PreviousClaim,
		  ISNULL([dbo].[GetClaimedAssessment](TI.TradeId,@AutoId,@ProjectId),0)ClaimedAmount
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
		JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 GROUP BY TI.TradeId,TM.TradeName,TI.ProjectId
END



go

