CREATE PROC [dbo].[GetAssementList](@ProjectId bigint,@TradeId int)
AS
BEGIN
	SELECT TI.Id,TI.TradeId,TI.[Level],TI.DescriptionOfWork,TI.ProjectId,TI.ItemBreakdown,TM.TradeName,
		ISNULL([dbo].[GetAssessmentTotalClaim](TI.ID),0)TotalClaim,
		ISNULL([dbo].[GetAssessmentPreviousClaim](TI.ID),0)PreviousClaim,
		ISNULL([dbo].[GetAssessmentClaimID](TI.ID),0)ClaimHistoryID,
		ISNULL([dbo].[GetActionClaim](TI.ID),null)ActionClaim
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
		JOIN Project AS P On P.id = @ProjectId
	WHERE TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 and Ti.TradeId= @TradeId 
END



go

