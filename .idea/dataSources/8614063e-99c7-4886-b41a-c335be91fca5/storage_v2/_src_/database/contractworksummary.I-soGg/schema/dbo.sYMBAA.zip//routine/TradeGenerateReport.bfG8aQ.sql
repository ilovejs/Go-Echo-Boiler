
CREATE PROC [dbo].[TradeGenerateReport](@ProjectId bigint,@TradeId int,@Month varchar(50),@ClaimNumber varchar(200))
--exec TradeGenerateReport 20262,33

AS
DECLARE @RCount int
BEGIN
   SELECT @RCount=COUNT(TI.TradeId)
		  FROM TradeItem AS TI
			JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
			JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId  AND TI.TempCheck = 0 AND TI.TradeId = @TradeId--IN (33,34,35,36,37) 
	GROUP BY TI.TradeId,TM.TradeName,TI.ProjectId,P.Name
	ORDER BY TI.TradeId

	IF @RCount > 0
	BEGIN
	SELECT TI.TradeId AS TradeId,TM.TradeName AS TradeName,ISNULL(SUM(TI.ItemBreakdown),0) AS ItemBreakdownAmount,
	     ISNULL([dbo].[GetClaimedAssessmentReport](TI.TradeId,@ProjectId,@Month,@ClaimNumber),0)ClaimedAmount,
		 ISNULL([dbo].[GetReportPreviousClaim](TI.TradeId,@ProjectId,(TC.AutoIncrement-1)),0)PreviousClaim
		 FROM TradeItem AS TI
			JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
			JOIN TradeItemClaim AS TC ON TC.TradeItemId = TI.Id
			JOIN Project AS P On P.id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId  AND TC.ClaimPeriod = @Month AND TC.ClaimNumber =  @ClaimNumber AND TI.TempCheck = 0 AND TI.TradeId = @TradeId --IN (33,34,35,36,37) 
	GROUP BY TI.TradeId,TM.TradeName,TI.ProjectId,P.Name,TC.ClaimNumber,TC.ClaimPeriod,TC.AutoIncrement
	ORDER BY TI.TradeId
	END
	ELSE
	BEGIn
	SELECT TM.Id AS TradeId,TM.TradeName AS TradeName,0.00 AS ItemBreakdownAmount,
	      0.00 AS ClaimedAmount,
		  0.00 AS PreviousClaim
		  FROM TradeMaster AS TM
	WHERE TM.Id =@TradeId --IN (33,34,35,36,37) 
    ORDER BY TM.Id
	END
END



go

