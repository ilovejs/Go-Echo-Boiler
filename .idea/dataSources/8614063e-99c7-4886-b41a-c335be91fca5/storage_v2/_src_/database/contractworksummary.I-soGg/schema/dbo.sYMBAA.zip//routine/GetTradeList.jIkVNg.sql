CREATE   PROC [dbo].[GetTradeList](@ProjectId bigint)
AS
/*
exec GetTradeList 10200
*/
BEGIN
	SELECT TI.Id,TI.TradeId,TI.ProjectId,TI.[Level],TI.DescriptionOfWork,TI.ItemBreakdown,TM.TradeName
	FROM TradeItem AS TI
		JOIN TradeMaster AS TM ON TM.Id = TI.TradeId
	WHERE  TI.ProjectId = @ProjectId AND TI.IsDeleted = 0 AND TI.TempCheck = 0 AND TM.IsDeleted = 0
	ORDER BY TI.Id 
END



go

