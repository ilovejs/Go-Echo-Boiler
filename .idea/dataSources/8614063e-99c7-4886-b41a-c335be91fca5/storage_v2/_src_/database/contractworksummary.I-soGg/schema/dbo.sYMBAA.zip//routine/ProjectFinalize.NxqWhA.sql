CREATE  PROC [dbo].[ProjectFinalize](@ProjectId bigint)
AS
/*
 exec ProjectFinalize
*/
BEGIN
	UPDATE TradeItem
	SET TempCheck = 0
    WHERE  ProjectId = @ProjectId
	
	SELECT TradeId,ProjectId,SUM(ItemBreakDown) AS Total,
	[dbo].[GetTotalAmount](@ProjectId)TotalItemBreakDown
	FROM TradeItem
	WHERE ProjectId = @ProjectId AND TempCheck = 0 group by TradeId ,ProjectId
END



go

