CREATE function [dbo].[GetActiveTradeItemCount](@ProjectId bigint)
returns int
as    
begin    
	Declare @ItemCnt int
	select @ItemCnt=count(Q.Id) from TradeItem as  Q 
		join TradeMaster as tm on tm.Id = Q.TradeId
	where Q.ProjectId=@ProjectId and isnull(Q.isdeleted,0)=0 and tm.isdeleted = 0 and Q.TempCheck = 0
	return @ItemCnt
end
go

