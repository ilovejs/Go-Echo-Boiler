
CREATE function [dbo].[GetReportClaimAmount](@TradeItemId bigint)
returns decimal(18,2)
as    
begin    
	Declare @PClaimAmount Decimal(18,2)
	select top 1  @PClaimAmount= ClaimedAmount  from  TradeItemClaim
	where TradeItemId =@TradeItemId and ActionClaim = 0
	order by AutoIncrement desc
	return @PClaimAmount
end

go

