CREATE function [dbo].[GetCostToCompleted](@TradeItemId int)
returns decimal(18,2)
as    
begin    
	Declare @CTC Decimal(18,2)
	select top 1  @CTC= SUM(TC.CostToCompleted) from TradeItem as TT join TradeItemClaim as TC on TT.Id=TC.TradeItemId
	where TT.TradeId =@TradeItemId
	return @CTC
end
go

