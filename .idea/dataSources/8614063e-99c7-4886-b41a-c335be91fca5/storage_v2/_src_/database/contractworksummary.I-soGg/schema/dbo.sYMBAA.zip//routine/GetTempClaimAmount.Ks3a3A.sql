
CREATE function [dbo].[GetTempClaimAmount](@TradeItemId bigint)
returns decimal(18,2)
as    
begin    
	Declare @PClaimAmount Decimal(18,2)
	select  @PClaimAmount= ClaimedAmount  from  TradeItemClaim
	where TradeItemId =@TradeItemId and ActionClaim is null --and AutoIncrement = MAX(AutoIncrement)
	return @PClaimAmount
end
go

