
CREATE PROC [dbo].[GetProjectAmountOfTrade](@ProjectId bigint)
AS
/*
exec GetProjectAmountOfTrade 20272
*/
BEGIN
	SELECT ISNULL(SUM(TI.ItemBreakdown),0) AS ItemBreakdown, P.TotalContractAmount	FROM TradeItem AS TI
		JOIN Project AS P ON P.Id = @ProjectId
	WHERE  TI.ProjectId = @ProjectId AND TI.IsDeleted = 0 AND TI.TempCheck = 0 
	GROUP BY P.TotalContractAmount
	
END



go

